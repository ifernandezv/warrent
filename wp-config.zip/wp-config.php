<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', false); //Added by WP-Cache Manager
define( 'WPCACHEHOME', '' ); //Added by WP-Cache Manager
define('DB_NAME', 'warrent');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'i3|+vw*1,h>(2sFXA@QV|bZ a[{xW{=)1551@/n5^?u| E<;G&N9l@.H~VT,TNK?');
define('SECURE_AUTH_KEY',  'VpJe!:BE+grS![%_Vy|v-`fL=`ol|p~oh&s82#|2m+BO:^Gu&})KB!Wt{R{Va0Xv');
define('LOGGED_IN_KEY',    ';jP7~CY:3dnf-y1Gr4tw}Z=!W=$FK*)GJp.brL$(+]1a2n0 s/()&HCcczfSb|fI');
define('NONCE_KEY',        '0 esS~A?P6@PGIxk:[l~=IwL$Q9|71CiH,v-3[[dHGtCm-[;>n3R~HV,KMpEcN>J');
define('AUTH_SALT',        'r>,nJAJKAI>T3k$vGbT$4Q-wP:n1x<?ilP22]2tD$M*yQtB?tIoeEyU]%cDWNkUp');
define('SECURE_AUTH_SALT', 'V<n66Ep-/$03[3_CPU01`5+rN*5n(^@OLQl=*H2?LNbdwgdG.+|7{]s;@F8[sYg`');
define('LOGGED_IN_SALT',   '27REho-4c-=NQn3fP]Bb5x2H;O.+Mq~xEJ9Bq;iInJ9%}Y!mQAP>O6QXZwVgQ8{i');
define('NONCE_SALT',       'DHMQ0|c%|npBx!m4%w1kBG..w,?N5o+t2k9s-wJyT4KR :s{-0mvw9#mqp|rcEr|');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
